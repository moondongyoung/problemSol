using DataStrucuture;
using UnityEngine;

public class ObjectPoolManager : MonoBehaviour
{
    public GameObject Bullet04Prefab;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
