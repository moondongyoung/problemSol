using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MidtermPlayer : MonoBehaviour
{
    public float moveSpeed = 8f;
    private Vector3 startPosition = new Vector3(-25f, 35f, -25f);
    private Vector3 targetPosition = new Vector3(-30f, 45f, -40f);

    // �̵� �ð�
    public float moveTime = 1f;

    // �̵� �ӵ�
    private float inverseMoveTime;

    // �̵� ����
    private bool isMoving = false;
    // Start is called before the first frame update
    void Start()
    {
        inverseMoveTime = 1f / moveTime;
    }

    // Update is called once per frame
    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal"); // �¿� ȭ��ǥ Ű �Է�
        float verticalInput = Input.GetAxis("Vertical"); // ���� ȭ��ǥ Ű �Է�
        Vector3 moveDirection = new Vector3(horizontalInput, 0f, verticalInput).normalized; // �̵� ������ ����ȭ
        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);
        if (!isMoving && Input.GetKeyDown(KeyCode.O))
        {
            StartCoroutine(MoveCamera(targetPosition));
        }
    }
    private IEnumerator MoveCamera(Vector3 targetPosition)
    {
        isMoving = true;
        float elapsedTime = 0;

        Vector3 startingPos = transform.position;

        while (elapsedTime < moveTime)
        {
            transform.position = Vector3.Lerp(startingPos, targetPosition, (elapsedTime / moveTime));
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        // ��Ȯ�� ��ġ�� �̵�
        transform.position = targetPosition;
        isMoving = false;
    }
}
